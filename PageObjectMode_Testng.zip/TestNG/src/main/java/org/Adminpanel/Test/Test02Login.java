package org.Adminpanel.Test;

import org.Admin.pages.LoginPage;
import org.selenium.Base.BrosweBase;
import org.testng.annotations.Test;

public class Test02Login extends BrosweBase{

	@Test
public void loginTest()
{
	/*two ways ,one is using object ref to call method & another is return data
	LoginPage lin=new LoginPage();
	
	lin.enterUsername(username);
	lin.enterPassword(password);
	*/
	new LoginPage(driver)
	.enterUsername("8680097929")
	.enterPassword("Ashok@123")
	.clickLogin();
	
	
}
}
