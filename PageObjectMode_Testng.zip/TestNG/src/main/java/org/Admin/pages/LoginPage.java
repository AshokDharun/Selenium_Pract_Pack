package org.Admin.pages;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.selenium.Base.BrosweBase;

public class LoginPage extends BrosweBase {
	
	public LoginPage(RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	//RemoteWebDriver driver=null;
	//locater
	public boolean getUsernameLabel()
	{
		return driver.findElementByXPath("//label[@for='mat-input-0']").isDisplayed();
	}
	
	public boolean getPasswordLabel()
	{
		return driver.findElementByXPath("//label[@for='mat-input-1']").isDisplayed();
	}
	
	//Actions
	public LoginPage enterUsername(String username){
		driver.findElementByXPath("//input[@id='mat-input-0']").sendKeys(username);
		return this;
	}
	public LoginPage enterPassword(String password)
	{
		driver.findElementByXPath("//input[@id='mat-input-1']").sendKeys(password);	return this;
	}
	public Dashboardpage clickLogin()
	{
		driver.findElementByXPath("//button[@id='kt_login_signin_submit']").click(); return new Dashboardpage(driver);
	}
	
	public void login(String username,String password)
	{
		enterUsername(username);
		enterPassword(password);
		clickLogin();
		
	}
}
