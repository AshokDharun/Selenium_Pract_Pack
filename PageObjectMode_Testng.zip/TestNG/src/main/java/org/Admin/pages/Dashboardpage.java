package org.Admin.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

public class Dashboardpage extends LoginPage {

	public Dashboardpage(RemoteWebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
