package org.selenium.Base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BrosweBase {
	
	 protected RemoteWebDriver driver=null;
	
	@BeforeMethod
	public void startApp()
	{
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");	
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://52.66.129.203:4200/#/auth/login");
	}
	@AfterMethod
	public void closeApp()
	{
	driver.quit();	
	}

}
