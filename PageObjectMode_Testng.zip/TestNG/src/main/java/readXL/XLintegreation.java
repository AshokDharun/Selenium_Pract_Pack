package readXL;

import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class XLintegreation 
{
	public static XSSFRow row;
	public static XSSFCell cell;
	public static  String[][] getData() throws IOException
	{
		String filelocation="./Test_Data/Login_Data.xlsx";
		XSSFWorkbook book=new XSSFWorkbook(filelocation);
		XSSFSheet sheet=book.getSheetAt(1);
		int lrow=sheet.getLastRowNum();
		int lcell=sheet.getRow(0).getLastCellNum();
		String[][] data=new String[lrow][lcell];
		for(int i=0;i<lrow;i++)
		{
			row=sheet.getRow(i);
			for(int j=0;j<lcell;j++)
			{
				cell=row.getCell(j);
				cell.setCellType(CellType.STRING);
				String val=cell.getStringCellValue();
				System.out.println(val);
				 data[i-1][j]=val;
			}
		}book.close();
		return data;
	}
}
