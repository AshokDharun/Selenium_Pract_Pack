package readXL;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ReadData {

	public static void main(String[] args) throws Exception {
		Row row = null;
		Cell cell=null;
		String data=null;
		File file=new File("./Test_Data/Login_Data.xlsx");
		FileInputStream fis=new FileInputStream(file);
		Workbook wb=WorkbookFactory.create(fis);
		org.apache.poi.ss.usermodel.Sheet sheet=wb.getSheet("Sheet1");
		for(int i=1;i<=sheet.getLastRowNum();i++){
			row=sheet.getRow(i);
		for(int j=0;j<row.getLastCellNum();j++)
		{
			cell=row.getCell(j);
			cell.setCellType(CellType.STRING);
			data=cell.getStringCellValue();
			System.out.println(data);		
		}
			
			
		}


	}

}
