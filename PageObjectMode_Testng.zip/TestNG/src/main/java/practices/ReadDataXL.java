package practices;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;

public class ReadDataXL
{
	
public static String[][] rData() throws EncryptedDocumentException, IOException
{
	Row row;
	Cell cell;
	File file=new File("./Test_Data/Login_Data.xlsx");
	FileInputStream fin=new FileInputStream(file);
	Workbook wb=WorkbookFactory.create(fin);
	Sheet sheet=wb.getSheet("Sheet1");
	int lrow=sheet.getLastRowNum();
	int lcell=sheet.getRow(0).getLastCellNum();
	String[][] data=new String[lrow][lcell];
	for(int i=1;i<=sheet.getLastRowNum();i++)
	{
	row=sheet.getRow(i);	
	for(int j=0;j<row.getLastCellNum();j++)
	{
		cell=row.getCell(j);
		cell.setCellType(CellType.STRING);
		
	String val=cell.getStringCellValue();
	
		data[i-1][j]=val;
	}
	}
	return data;
}
}
