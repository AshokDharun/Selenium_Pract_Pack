package testng_Basic;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Alarthandling 
{
	@Test
public void Alart_Handling()
{
System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");	
ChromeDriver driver=new ChromeDriver();
driver.get("https://letcode.in/alert");
//simple alart
driver.findElement(By.id("accept")).click();
//driver.findElementById("accept").click();
Alert alrt=driver.switchTo().alert();
System.out.println(alrt.getText());
alrt.accept();//alrt.dismiss();


/*
//confirm alart
driver.findElementById("confirm").click();;
Alert alert=driver.switchTo().alert();
System.out.println(alert.getText());
//alert.accept();
alert.dismiss();

//promt alart

driver.findElementById("prompt").click();
Alert palrt=driver.switchTo().alert();
System.out.println(palrt.getText());
palrt.sendKeys("Ashok");
palrt.accept();
//palrt.dismiss();
System.out.println(driver.findElementById("myName").getText());
*/

}
}
