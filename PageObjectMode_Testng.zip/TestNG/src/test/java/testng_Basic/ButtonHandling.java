package testng_Basic;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ButtonHandling 
{
	@Test
public void Button_Handle() {
System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	
	ChromeDriver driver=new ChromeDriver();
	driver.get("https://letcode.in/buttons");
	
	WebElement ele=driver.findElement(By.id("position"));
	Point p=ele.getLocation();
	int x=p.getX();
	int y=p.getY();
	System.out.println("X=> "+x+"   Y=> "+y);
	//Find button color
	WebElement bcolor=driver.findElement(By.id("color"));
	String color=bcolor.getCssValue("background-color");
	System.out.println("Button color code "+ color);
	
	//Find hight & width of button
	Rectangle rect=driver.findElement(By.id("property")).getRect();
	int h=rect.getHeight();
	int w=rect.getWidth();
	
	System.out.println("hight "+ h+ " widtg  "+w+ " Point "+ rect.getPoint());
	//using diamention
	  Dimension d=rect.getDimension();
	  System.out.println("Dimamention value "+d);
	  d.getHeight();d.getWidth();
	  System.out.println("hight "+ d.getHeight()+ " widtg  "+d.getWidth());
	
	  //Button is enable?
	 boolean res= driver.findElement(By.id("isDisabled")).isEnabled();
	 System.out.println(res);
	
	//close 
	driver.quit();
}
}
