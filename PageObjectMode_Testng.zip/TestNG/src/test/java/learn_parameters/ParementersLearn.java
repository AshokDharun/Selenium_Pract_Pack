package learn_parameters;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParementersLearn 
{
	RemoteWebDriver driver;
	@Parameters({"email_ID","password","broswer"})
	@Test
	
	public void login(String email, String pass,String broswer)
	{
		System.out.println(email +"  "+ pass);
	
		switch (broswer) {
		case "chrome":
			driver=new ChromeDriver();
			break;
		case "firefox":
			driver=new FirefoxDriver();
		break;
		default:
			System.err.println("broswer not defined");
			break;
		}
		/*
	System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");	
	ChromeDriver driver=new ChromeDriver();
	*/
	driver.get("https://letcode.in/");
	driver.findElementByName("email").sendKeys("ask@email.com");
	driver.findElementByName("password").sendKeys("123");
	driver.findElementByName("button").click();
	
	}
}
