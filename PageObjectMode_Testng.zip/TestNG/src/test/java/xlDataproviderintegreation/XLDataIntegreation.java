package xlDataproviderintegreation;

import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import readXL.ReadXLData;
import readXL.XLintegreation;

public class XLDataIntegreation 
{
	
	
	@DataProvider(name="dataprovide")
public String[][] data() throws IOException
	{
		String[][] data =XLintegreation.getData();
		
		return data;
	}
	
	@Test(dataProvider="dataprovide",dataProviderClass=XLDataIntegreation.class)
public void login(String data[])
{	
	System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");	
	ChromeDriver driver=new ChromeDriver();
	driver.get("http://52.66.129.203:4200/#/auth/login");
	driver.findElementByXPath("//input[@id='mat-input-0']").sendKeys(data[0]);
	driver.findElementByXPath("//input[@id='mat-input-1']").sendKeys(data[1]);
	driver.findElementByXPath("//button[@id='kt_login_signin_submit']").click();
	System.out.println(driver.getCurrentUrl());
	driver.quit();
}
	

}
