package utils;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.DataProvider;

import readXL.ReadXLData;

public class DataUtils
{

	@DataProvider(/*indices={0,1},*/ parallel= !true)//indices is ued for index data row is execute, particular data row exe
public String[][] getdata() throws IOException
{
		String[][] data =ReadXLData.getXelData();
	/*String[][] data = new String[2][2];
	data[0][0]="8680097929";
	data[0][1]="Ashok@123";
	
	data[1][0]="";
	data[1][1]="";
	
	data[0][0]="8680097929";
	data[0][1]="Ashok@123";
	*/
	
	return data;
	
}
}
