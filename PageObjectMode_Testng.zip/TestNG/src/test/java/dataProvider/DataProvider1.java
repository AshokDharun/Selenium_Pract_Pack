package dataProvider;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import utils.DataUtils;

public class DataProvider1  //extends DataUtils
{
	//@Parameters({"email_ID"})- usung paramete& data provider in same time error get - data mismatch 
	@Test(dataProvider="getdata", dataProviderClass=DataUtils.class)
	public void login(String data[])
	{
		System.out.println("email_ID    :"+ data[0]);
		System.out.println("Password    :"+ data[1]);
		//System.err.println("pass"+ data[]);
		
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");	
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://52.66.129.203:4200/#/auth/login");
		driver.findElementByXPath("//input[@id='mat-input-0']").sendKeys(data[0]);
		driver.findElementByXPath("//input[@id='mat-input-1']").sendKeys(data[1]);
		driver.findElementByXPath("//button[@id='kt_login_signin_submit']").click();
		System.out.println(driver.getCurrentUrl());
		driver.quit();
			
	}
}
