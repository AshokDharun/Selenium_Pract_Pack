package testNG_Attributes;

import org.testng.annotations.Test;

public class LearnGroups 
{
	@Test(groups={"sanity"})
public void signUP()
{
	System.out.println("sing up");
}
	@Test(groups={"reg"})
public void logIn()
{
	System.out.println("  Login");
}
	@Test(groups={"smoke"})
public void searchProduct()
{
	System.out.println("search product");
}
	@Test(groups={"sanity"})
	public void Addcart()
	{
		System.out.println("cart");
	}
		
	
}
