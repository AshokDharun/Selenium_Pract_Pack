package testNG_Attributes;

import org.testng.annotations.Test;

public class LearnAttributes 
{
	@Test(priority=1)
void login()
{
	System.out.println("Login");
}
	@Test(priority=2)
void signup()
{
	System.out.println("sign up");
}
	@Test(priority=3)
void add()
{
	System.out.println("Add product");
}
	@Test(priority=4)
	void buy()
	{
		System.out.println("buy product ");
	}
	@Test(priority=-1)
	void signout()
	{
		System.out.println("signout");
	}
}
