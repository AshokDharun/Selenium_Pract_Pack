package testNG_Attributes;

import org.testng.annotations.Test;

public class Innovocation_Count 
{
	@Test(invocationCount=4,invocationTimeOut=2000)//maixmum no of iteraton in miliseconds
public void method()
{
System.out.println("Test innovaction count ");	
}
}
