package testNG_Attributes;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ThreadPool_Attribute
{
	//Threadpool size- innvocationcount need & parrel time exe
	@Test(enabled=false,invocationCount=3, threadPoolSize=2)//thread pool 2 mean  parrell exe of broswer
public void sample()
{
	System.out.println("Samples of learn attrubute");
	System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");	
	ChromeDriver driver=new ChromeDriver();
	driver.get("https://letcode.in/alert");
	//simple alart
	driver.findElement(By.id("accept")).click();
	//driver.findElementById("accept").click();
	Alert alrt=driver.switchTo().alert();
	System.out.println(alrt.getText());
}
	@Test(timeOut=1000)
	public void timeOut_attribute()
	{
		System.out.println("this time out attribute");
	}
	// this attribute ignore the exceptuon and show run sucess test case
	@Test(expectedExceptions={NoSuchElementException.class})
	public void exceptio_Attribute()
	{
		System.out.println("using excepted exception attribute");
		throw new org.openqa.selenium.NoSuchElementException("new error");
		
	}
}
