package testNG_Attributes;

import org.testng.annotations.Test;

public class DependsoN 
{
	@Test(priority=2)
	public void signUp()
	{
		System.out.println("Sign up");
	}
	@Test(dependsOnMethods="testNG_Attributes.DependsoN.signUp", priority=1)// depends on method is first exu bocz depends on is high prefer
											//depends on method - if failed test other test is skip but priority test other case
	//depends on method used on another class method is using fully classified class.method name 
	public void login()
	{
		System.out.println("Login ");
	}
	@Test(dependsOnMethods="login")
	public void searchProduct()
	{
		System.out.println("Search product");
	}
	@Test(dependsOnMethods="searchProduct")
	public void addToCart()
	{
		System.out.println("Add to  ccart");
	}
	@Test(dependsOnMethods="addToCart")
	public void logOut()
	{
		System.out.println("Sign out");
	}

}
