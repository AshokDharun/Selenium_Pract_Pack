package testNG_Attributes;

import java.util.NoSuchElementException;

import org.testng.annotations.Test;

public class LearnAttribute2 
{
	@Test(enabled=false)
	//when we r usring@Test(enabled=false, alwaysRun=true) means the enable attribute is high preference
public void signUp()
{
	System.out.println("sign up");
}
	@Test(description="this is uesd login")
public void logIn()
{
	System.out.println("login ");
	throw new org.openqa.selenium.NoSuchElementException("new error");
	
}
	@Test(dependsOnMethods="testNG_Attributes.LearnAttribute2.logIn",alwaysRun=true)
public void searchproduct()
{
	System.out.println("serh product");
}
}
