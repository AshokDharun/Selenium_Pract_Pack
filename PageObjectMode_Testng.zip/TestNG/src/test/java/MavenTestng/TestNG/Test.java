package MavenTestng.TestNG;

public class Test
{
	
	public void disp()
	{
		System.out.println("hay");
	}
}
