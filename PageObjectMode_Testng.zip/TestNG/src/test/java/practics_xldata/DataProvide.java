package practics_xldata;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.annotations.DataProvider;

import practices.ReadDataXL;

public class DataProvide 
{
	@DataProvider(name="p1",indices=1)
public String[][] setData() throws EncryptedDocumentException, IOException
{
		String[][] loginData=ReadDataXL.rData();
/*String[][] data=new String[2][2];
data[0][0]="8680097929";
data[0][1]="Ashok@123";

data[1][0]="";
data[1][1]="";

data[0][0]="8680097929";
data[0][1]="Ashok@123";

return data;*/
		return loginData;
}
}
