package practics_xldata;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DataLogin 
{
	@Test(dataProvider="p1",dataProviderClass=DataProvide.class)
	public void login(String data[])
	{
		System.out.println("email_ID    :"+ data[0]);
		System.out.println("Password    :"+ data[1]);
		
	System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");	
	ChromeDriver driver=new ChromeDriver();
	driver.get("http://52.66.129.203:4200/#/auth/login");
	driver.findElementByXPath("//input[@id='mat-input-0']").sendKeys(data[0]);
	driver.findElementByXPath("//input[@id='mat-input-1']").sendKeys(data[1]);
	driver.findElementByXPath("//button[@id='kt_login_signin_submit']").click();
	System.out.println(driver.getCurrentUrl());
	driver.quit();
	
}
}
